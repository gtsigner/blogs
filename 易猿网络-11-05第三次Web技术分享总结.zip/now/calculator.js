
var x=0;
var y=0;

function add(x,y){
    return x+y;
}

function subtract(x,y){
    return x-y;
}


module.exports.add=add;
module.exports.subtract=subtract;